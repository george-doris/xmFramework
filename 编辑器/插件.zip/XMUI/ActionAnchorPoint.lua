local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local err = {}
    table.insert(err,"[")
    table.insert(err, ActionTag[root["@ActionTag"]].name)
    
    table.insert(err,"]不支持[描点]动画")
    
    error(table.concat(err))
end