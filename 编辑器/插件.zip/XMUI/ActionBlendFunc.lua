local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
end