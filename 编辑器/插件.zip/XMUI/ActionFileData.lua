local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local frames = {}
    local obj = {
        frames = frames
    }

    for index, value in pairs(root.TextureFrame) do
        local child = {}
        child.frameIndex = tonumber(value["@FrameIndex"])
        child.tween = value["@Tween"]=="False" and false or true
        child.file = XmlObjectHelper.PngToBlp(value.TextureFile[1]["@Path"])

        table.insert(frames,child)
    end

    return obj
end