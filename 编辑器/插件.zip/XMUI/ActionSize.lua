local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local frames = {}
    local obj = {
        frames = frames
    }

    for index, value in pairs(root.SizeFrame) do
        local child = {}
        child.frameIndex = tonumber(value["@FrameIndex"])
        child.tween = value["@Tween"]=="False" and false or true
        child.x = tonumber(value["@X"]) / SolutionSize.width*0.8
        child.y = tonumber(value["@Y"]) / SolutionSize.height*0.6
        if value.EasingData then
            child.easingData = value.EasingData[1]["@Type"]
        end

        table.insert(frames,child)
    end

    return obj
end