local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local obj = {}
    obj.ctype = root["@ctype"]
    --名字
    obj.name = XmlObjectHelper.GetName(root)
    --动画tag
    obj.actionTag = XmlObjectHelper.GetActionTag(root)
    --tag
    obj.tag = XmlObjectHelper.GetTag(root)
    --触摸应用
    obj.callBackType = XmlObjectHelper.CallBackType(root)
    --触摸应用
    obj.callBackName = XmlObjectHelper.GetCallBackName(root)
    --用户数据
    obj.userData = XmlObjectHelper.GetUserData(root)
    --帧事件
    obj.frameEvent = XmlObjectHelper.GetFrameEvent(root)
    --回调方法
    obj.touchEnable = XmlObjectHelper.GetTouchEnable(root)
    --是否显示
    obj.visible = XmlObjectHelper.GetVisible(root)
    --大小
    obj.width,obj.height = XmlObjectHelper.GetSize(root,scene)
    --缩放
    obj.scale = XmlObjectHelper.GetScale(root)
    --位置
    obj.x,obj.y = XmlObjectHelper.GetPosition(root,scene)
    --位置
    obj.anchorType = XmlObjectHelper.GetAnchorPoint(root)
    --颜色
    obj.color = XmlObjectHelper.GetColor(root)
    --透明
    obj.alpha = XmlObjectHelper.GetAlpha(root)
    --检测倾斜
    XmlObjectHelper.GetRotationSkew(root)
    
    --状态
    obj.state = XmlObjectHelper.GetDisplayState(root)
    
    --字体大小
    obj.fontSize = XmlObjectHelper.GetFontSize(root)
    --字体文件
    obj.font = XmlObjectHelper.CopyRes(root,XmlObjectHelper.GetResource(root,"FontResource"))
    --文本
    obj.text = XmlObjectHelper.GetButtonText(root)
    --字体颜色
    obj.textColor = XmlObjectHelper.GetTextColor(root)
    --影子偏移
    obj.shadowOffset = XmlObjectHelper.GetShadowOffset(root,scene)
    --影子颜色
    obj.shadowColor = XmlObjectHelper.GetShadowColor(root)
    --描边颜色
    obj.outlineColor = XmlObjectHelper.GetOutlineColor(root)
    
    --禁用图片
    obj.disableImage = XmlObjectHelper.CopyRes(root,XmlObjectHelper.GetResource(root,"DisabledFileData"))
    --按下图片
    obj.pressedImage = XmlObjectHelper.CopyRes(root,XmlObjectHelper.GetResource(root,"PressedFileData"))
    --按下图片
    obj.normalImage = XmlObjectHelper.CopyRes(root,XmlObjectHelper.GetResource(root,"NormalFileData"))
    --检测九宫格
    XmlObjectHelper.GetScale9Enable(root)
    
    local Children = root.Children
    if Children then
        obj.children = ParserChildren(Children[1],scene)
    end

    return obj
end