local XmlObjectHelper = require "XmlObjectHelper"
local fs = require "file_system"

function ParserAnimationInfo(AnimationList,scene)
    local childs = {}
    local animationInfo
    for index, value in pairs(AnimationList.AnimationInfo) do
        animationInfo = {}
        animationInfo.name = value["@Name"]
        animationInfo.startIndex = tonumber(value["@StartIndex"])
        animationInfo.endIndex = tonumber(value["@EndIndex"])

        childs[animationInfo.name] = animationInfo
    end
    return childs
end

function ParserAnimation(Animation,scene)
    local animation = {}
    animation.duration = tonumber(Animation["@Duration"])
    animation.speed = tonumber(Animation["@Speed"])

    if Animation.Timeline then
        local childs = {}
        for index, value in pairs(Animation.Timeline) do
            local property = value["@Property"]
            local parserFrame = require("Action"..property)
            local child = parserFrame(value,scene)
            if child then
                child.property = property
                child.actionTag = value["@ActionTag"]
                
                table.insert(childs,child)
            end
        end
        animation.timeline = childs
    end
    return animation
end

function ParserChildren(Children,scene)
    local childs = {}
    for index, value in pairs(Children.AbstractNodeData) do
        local ctype = value["@ctype"]
        local parserObject = require(ctype)
        local child = parserObject(value,scene)
        table.insert(childs,child)
    end
    return childs
end

return function (inFile,outFile)
    --#regions 保存源文件
    -- local f = io.open(inFile,"r")
    -- local buffer = f:read("a")
    -- f:close()
    -- local fs = require "file_system"
    -- local srcFile = fs.renameExtension(outFile,".src")
    -- f = io.open(srcFile,"w")
    -- f:write(buffer)
    -- f:close()
    --#endregion

    ActionTag = {}

    print("************************************************************")
    print('开始解析  '..inFile)
    --#regions 解析文件
    local scene = {}
    local xml = require("xmlSimple").newParser()
    local root = xml:loadFile(inFile)
    root = root.GameFile[1]
    --场景名称
    local child = root.PropertyGroup[1]
    scene.name = child["@Name"]
    print('场景名称:'..scene.name)
    root = root.Content[1].Content[1]
    ---物体
    local ObjectData = root.ObjectData[1]
    scene.className = ObjectData["@CustomClassName"]
    scene.userData = ObjectData["@UserData"]
    child = ObjectData.Size[1]
    scene.width = tonumber(child["@X"])
    scene.height = tonumber(child["@Y"])
    if ObjectData.Children then
        local Children = ObjectData.Children[1]
        scene.children = ParserChildren(Children,scene)
    else
        XmlObjectHelper.Error(scene,"场景内没有任何元素")
    end
    --动画
    if root.Animation then
        scene.animation = ParserAnimation(root.Animation[1],scene)
    end
    local Animation = root.Animation[1]

    --动画列表
    if root.AnimationList then
        scene.animationList = ParserAnimationInfo(root.AnimationList[1],scene)
    end
    local Serialize = require "Serialize"
    buffer = Serialize.serialize(scene)

    --直接输出到map目录
    local filename = fs.pathStripPath(outFile)
    local tmp = fs.removeBackslash(outFile)
    tmp = fs.removeFileSpec(tmp)
    tmp = fs.pathAppend(tmp,"map")
    fs.createDirectory(tmp)

    outFile = fs.pathAppend(tmp,filename)
    
    local f = io.open(outFile,"w")
    if f then
        f:write(buffer)
        f:close()
    else
        XmlObjectHelper.Error(scene,"不能写入文件")
    end
   
    --#endregion

    print(scene.name..'导出成功\r\n')

    return ""
end