local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local obj = {}
    obj.ctype = root["@ctype"]
    --名字
    obj.name = XmlObjectHelper.GetName(root)
    --动画tag
    obj.actionTag = XmlObjectHelper.GetActionTag(root)
    --tag
    obj.tag = XmlObjectHelper.GetTag(root)
    --触摸应用
    obj.callBackType = XmlObjectHelper.CallBackType(root)
    --触摸应用
    obj.callBackName = XmlObjectHelper.GetCallBackName(root)
    --用户数据
    obj.userData = XmlObjectHelper.GetUserData(root)
    --帧事件
    obj.frameEvent = XmlObjectHelper.GetFrameEvent(root)
    --回调方法
    obj.touchEnable = XmlObjectHelper.GetTouchEnable(root)
    --是否显示
    obj.visible = XmlObjectHelper.GetVisible(root)
    --大小
    obj.width,obj.height = XmlObjectHelper.GetSize(root,scene)
    --缩放
    obj.scale = XmlObjectHelper.GetScale(root)
    --位置
    obj.x,obj.y = XmlObjectHelper.GetPosition(root,scene)
    --位置
    obj.anchorType = XmlObjectHelper.GetAnchorPoint(root)
    --颜色
    obj.color = XmlObjectHelper.GetColor(root)
    --透明
    obj.alpha = XmlObjectHelper.GetAlpha(root)
    --检测倾斜
    XmlObjectHelper.GetRotationSkew(root)
    
    --是否裁剪
    obj.clip = XmlObjectHelper.GetClipAble(root)
    --图片
    obj.image = XmlObjectHelper.CopyRes(root,XmlObjectHelper.GetResource(root,"FileData"))
    --图片宽度
    obj.image_width = XmlObjectHelper.GetScale9Width(root,scene)
    --图片高度
    obj.image_height = XmlObjectHelper.GetScale9Height(root,scene)
    
    --检测背景填充
    XmlObjectHelper.GetComboBoxIndex(root)
    --检测单色
    XmlObjectHelper.GetSingleColor(root)
    --检测开始颜色
    XmlObjectHelper.GetFirstColor(root)
    --检测结束颜色
    XmlObjectHelper.GetEndColor(root)
    --检测渐变方向
    XmlObjectHelper.GetColorVector(root)
    --检测九宫格
    obj.scale9 = XmlObjectHelper.GetScale9Enable(root,true)

    
    local Children = root.Children
    if Children then
        obj.children = ParserChildren(Children[1],scene)
    end
    
    return obj
end