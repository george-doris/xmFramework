return function(root,scene)
    local err = {}
    table.insert(err,"[")
    table.insert(err,scene.name)
    table.insert(err,"]不支持[粒子]控件")
    
    error(table.concat(err))
end