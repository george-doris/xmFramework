local fs = require "file_system"

local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local obj = {}
    obj.ctype = root["@ctype"]
    --名字
    obj.name = XmlObjectHelper.GetName(root)
    --动画tag
    obj.actionTag = XmlObjectHelper.GetActionTag(root)
    --tag
    obj.tag = XmlObjectHelper.GetTag(root)
    --触摸应用
    obj.callBackType = XmlObjectHelper.CallBackType(root)
    --触摸应用
    obj.callBackName = XmlObjectHelper.GetCallBackName(root)
    --用户数据
    obj.userData = XmlObjectHelper.GetUserData(root)
    --帧事件
    obj.frameEvent = XmlObjectHelper.GetFrameEvent(root)
    --回调方法
    obj.touchEnable = XmlObjectHelper.GetTouchEnable(root)
    --是否显示
    obj.visible = XmlObjectHelper.GetVisible(root)
    --大小
    obj.width,obj.height = XmlObjectHelper.GetSize(root,scene)
    --缩放
    obj.scale = XmlObjectHelper.GetScale(root)
    --位置
    obj.x,obj.y = XmlObjectHelper.GetPosition(root,scene)
    --位置
    obj.anchorType = XmlObjectHelper.GetAnchorPoint(root)
    --颜色
    obj.color = XmlObjectHelper.GetColor(root)
    --透明
    obj.alpha = XmlObjectHelper.GetAlpha(root)
    
    --透明
    obj.value = XmlObjectHelper.GetPercentInfo(root)

    --背景地图
    obj.backGround = XmlObjectHelper.PngToBlp(XmlObjectHelper.GetResource(root,"BackGroundData"))
    --内部样式
    obj.progressBar = XmlObjectHelper.PngToBlp(XmlObjectHelper.GetResource(root,"ProgressBarData"))
    --正常样式
    obj.ballNormal = XmlObjectHelper.PngToBlp(XmlObjectHelper.GetResource(root,"BallNormalData"))
    --按下样式
    obj.ballPressed = XmlObjectHelper.PngToBlp(XmlObjectHelper.GetResource(root,"BallPressedData"))
    --禁用样式
    obj.ballDisabled = XmlObjectHelper.PngToBlp(XmlObjectHelper.GetResource(root,"BallDisabledData"))

    --检测倾斜
    if XmlObjectHelper.GetRotationSkew90(root) then
        obj.direction = 0
        local t = obj.width
        obj.width = obj.height
        obj.height = t
        obj.anchorType = XmlObjectHelper.GetRotationAnchor90(root,obj.anchorType)
 
        if obj.backGround then
            obj.backGround = XmlObjectHelper.GetRotationPng90(root,obj.backGround,fs.renameExtension(obj.backGround,'_r90.png'))
        end
        if obj.progressBar then
            obj.progressBar = XmlObjectHelper.GetRotationPng90(root,obj.progressBar,fs.renameExtension(obj.progressBar,'_r90.png'))
        end
        if obj.ballNormal then
            obj.ballNormal = XmlObjectHelper.GetRotationPng90(root,obj.ballNormal,fs.renameExtension(obj.ballNormal,'_r90.png'))
        end
        if obj.ballPressed then
            obj.ballPressed = XmlObjectHelper.GetRotationPng90(root,obj.ballPressed,fs.renameExtension(obj.ballPressed,'_r90.png'))
        end
        if obj.ballDisabled then
            obj.ballDisabled = XmlObjectHelper.GetRotationPng90(root,obj.ballDisabled,fs.renameExtension(obj.ballDisabled,'_r90.png'))
        end
    else
        obj.direction = 1
    end
    if obj.backGround then
        obj.backGround = XmlObjectHelper.PngToBlp(obj.backGround )
    end
    if obj.progressBar then
        obj.progressBar = XmlObjectHelper.PngToBlp(obj.progressBar )
    end
    if obj.ballNormal then
        obj.ballNormal = XmlObjectHelper.PngToBlp(obj.ballNormal )
    end
    if obj.ballPressed then
        obj.ballPressed = XmlObjectHelper.PngToBlp(obj.ballPressed )
    end
    if obj.ballDisabled then
        obj.ballDisabled = XmlObjectHelper.PngToBlp(obj.ballDisabled )
    end
    
    local Children = root.Children
    if Children then
        obj.children = ParserChildren(Children[1],scene)
    end
    
    return obj
end