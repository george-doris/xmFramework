local fs = require "file_system"

local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local obj = {}
    obj.ctype = root["@ctype"]
    --名字
    obj.name = XmlObjectHelper.GetName(root)
    --动画tag
    obj.actionTag = XmlObjectHelper.GetActionTag(root)
    ActionTag[obj.actionTag] = obj
    --tag
    obj.tag = XmlObjectHelper.GetTag(root)
    --触摸应用
    obj.callBackType = XmlObjectHelper.CallBackType(root)
    --触摸应用
    obj.callBackName = XmlObjectHelper.GetCallBackName(root)
    --用户数据
    obj.userData = XmlObjectHelper.GetUserData(root)
    --帧事件
    obj.frameEvent = XmlObjectHelper.GetFrameEvent(root)
    --回调方法
    obj.touchEnable = XmlObjectHelper.GetTouchEnable(root)
    --是否显示
    obj.visible = XmlObjectHelper.GetVisible(root)
    --大小
    obj.width,obj.height = XmlObjectHelper.GetSize(root,scene)
    --缩放
    obj.scale = XmlObjectHelper.GetScale(root)
    --位置
    obj.x,obj.y = XmlObjectHelper.GetPosition(root,scene)
    --位置
    obj.anchorType = XmlObjectHelper.GetAnchorPoint(root)
    --颜色
    obj.color = XmlObjectHelper.GetColor(root)
    --透明
    obj.alpha = XmlObjectHelper.GetAlpha(root)
    
    --透明
    obj.value = XmlObjectHelper.GetPercentInfo(root)

    --背景地图
    obj.backGround = XmlObjectHelper.GetResource(root,"BackGroundData")
    --内部样式
    obj.progressBar = XmlObjectHelper.GetResource(root,"ProgressBarData")
    --正常样式
    obj.ballNormal = XmlObjectHelper.GetResource(root,"BallNormalData")
    --按下样式
    obj.ballPressed = XmlObjectHelper.GetResource(root,"BallPressedData")
    --禁用样式
    obj.ballDisabled = XmlObjectHelper.GetResource(root,"BallDisabledData")

    --检测倾斜
    if XmlObjectHelper.GetRotationSkew90(root) then
        obj.direction = 0
        local t = obj.width
        obj.width = obj.height
        obj.height = t
        obj.anchorType = XmlObjectHelper.GetRotationAnchor90(root,obj.anchorType)
 
        if obj.backGround then
            obj.backGround = XmlObjectHelper.CopyRes(root,obj.backGround,XmlObjectHelper.GetRotationSkewK(root))
        end
        if obj.progressBar then
            obj.progressBar = XmlObjectHelper.CopyRes(root,obj.progressBar,XmlObjectHelper.GetRotationSkewK(root))
        end
        if obj.ballNormal then
            obj.ballNormal = XmlObjectHelper.CopyRes(root,obj.ballNormal,XmlObjectHelper.GetRotationSkewK(root))
        end
        if obj.ballPressed then
            obj.ballPressed = XmlObjectHelper.CopyRes(root,obj.ballPressed,XmlObjectHelper.GetRotationSkewK(root))
        end
        if obj.ballDisabled then
            obj.ballDisabled = XmlObjectHelper.CopyRes(root,obj.ballDisabled,XmlObjectHelper.GetRotationSkewK(root))
        end
    else
        obj.direction = 1

        if obj.backGround then
            obj.backGround = XmlObjectHelper.CopyRes(root,obj.backGround)
        end
        if obj.progressBar then
            obj.progressBar = XmlObjectHelper.CopyRes(root,obj.progressBar)
        end
        if obj.ballNormal then
            obj.ballNormal = XmlObjectHelper.CopyRes(root,obj.ballNormal)
        end
        if obj.ballPressed then
            obj.ballPressed = XmlObjectHelper.CopyRes(root,obj.ballPressed)
        end
        if obj.ballDisabled then
            obj.ballDisabled = XmlObjectHelper.CopyRes(root,obj.ballDisabled)
        end
    end
    
    local Children = root.Children
    if Children then
        obj.children = ParserChildren(Children[1],scene)
    end
    
    return obj
end