local XmlObjectHelper = require "XmlObjectHelper"

return function (root,scene)
    local obj = {}
    obj.ctype = root["@ctype"]
    --名字
    obj.name = XmlObjectHelper.GetName(root)
    --动画tag
    obj.actionTag = XmlObjectHelper.GetActionTag(root)
    --tag
    obj.tag = XmlObjectHelper.GetTag(root)
    --触摸应用
    obj.callBackType = XmlObjectHelper.CallBackType(root)
    --触摸应用
    obj.callBackName = XmlObjectHelper.GetCallBackName(root)
    --用户数据
    obj.userData = XmlObjectHelper.GetUserData(root)
    --帧事件
    obj.frameEvent = XmlObjectHelper.GetFrameEvent(root)
    --回调方法
    obj.touchEnable = XmlObjectHelper.GetTouchEnable(root)
    --是否显示
    obj.visible = XmlObjectHelper.GetVisible(root)
    --大小
    obj.width,obj.height = XmlObjectHelper.GetSize(root,scene)
    --缩放
    obj.scale = XmlObjectHelper.GetScale(root)
    --位置
    obj.x,obj.y = XmlObjectHelper.GetPosition(root,scene)
    --位置
    obj.anchorType = XmlObjectHelper.GetAnchorPoint(root)
    --颜色
    obj.color = XmlObjectHelper.GetColor(root)
    --透明
    obj.alpha = XmlObjectHelper.GetAlpha(root)
    --检测倾斜
    XmlObjectHelper.GetRotationSkew(root)


    --文件
    obj.image = XmlObjectHelper.CopyRes(root,XmlObjectHelper.GetResource(root,"FileData"))
    --检测BlendFunc
    XmlObjectHelper.GetBlendFunc(root)
    --检测翻转x,y
    XmlObjectHelper.GetFlip(root)

    local Children = root.Children
    if Children then
        obj.children = ParserChildren(Children[1],scene)
    end
    
    return obj
end