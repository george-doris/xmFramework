local fs = require "file_system"

local XmlObjectHelper = {}

XmlObjectHelper.AnchorType = {
    LEFT_TOP = 0,
    TOP = 1,
    RIGHT_TOP = 2,
    LEFT = 3,
    CENTER = 4,
    RIGHT = 5,
    LEFT_BOTTOM = 6,
    BOTTOM = 7,
    RIGHT_BOTTOM = 8
}

XmlObjectHelper.AlignmentType = {
    TOP = 0,
    VCENTER = 2,
    BOTTOM = 4,
    LEFT = 0,
    CENTER = 16,
    RIGHT = 32,
}

function XmlObjectHelper.Tip(root, err)
    local t = {}
    table.insert(t, "[")
    table.insert(t, root["@Name"])
    table.insert(t, "]")
    table.insert(t, err)
    print(table.concat(t))
end

function XmlObjectHelper.Error(root, err)
    local t = {}
    table.insert(t, "[")
    table.insert(t, root["@Name"] or root.name)
    table.insert(t, "]")
    table.insert(t, err)
    local err = table.concat(t)
    print("\r\n\r\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    print("[error]" .. err)
    print("\r\n~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\r\n\r\n")
    error(table.concat(t))
end

function XmlObjectHelper.GetName(root)
    return root["@Name"]
end

function XmlObjectHelper.GetActionTag(root)
    return root["@ActionTag"]
end

function XmlObjectHelper.GetTag(root)
    return tonumber(root["@Tag"])
end

function XmlObjectHelper.GetUserData(root)
    return root["@UserData"]
end

function XmlObjectHelper.GetFrameEvent(root)
    return root["@FrameEvent"]
end

function XmlObjectHelper.GetLabelText(root)
    return root["@LabelText"]
end

function XmlObjectHelper.GetPlaceHolderText(root)
    XmlObjectHelper.Tip(root, "不支占位文本,在游戏不会显示")
    return root["@PlaceHolderText"]
end

function XmlObjectHelper.GetDirectionType(root)
    return root["@DirectionType"] == "Vertical" and 0 or 1
end

function XmlObjectHelper.GetContentAlign(root)
    if XmlObjectHelper.GetDirectionType(root) == 0 then
        if root["@HorizontalType"] == "Align_Right" then
            return 2
        end
        if root["@HorizontalType"] == "Align_HorizontalCenter" then
            return 1
        end
        return 0
    else
        if root["@VerticalType"] == "Align_VerticalCenter" then
            return 1
        end
        if root["@VerticalType"] == "Align_Bottom" then
            return 2
        end
        return 0
    end
end

function XmlObjectHelper.GetItemMargin(root)
    return tonumber(root["@ItemMargin"] or 0)
end

function XmlObjectHelper.GetPercentInfo(root)
    return tonumber(root["@PercentInfo"] or 0)
end

function XmlObjectHelper.GetComboBoxIndex(root)
    local tmp = tonumber(root["@ComboBoxIndex"] or 0)
    if tmp > 0 then
        XmlObjectHelper.Tip(root, "不支持背景填充,在游戏不会显示")
    end
    return tmp
end

function XmlObjectHelper.GetOutlineEnabled(root)
    if root["@OutlineEnabled"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.GetOutlineSize(root)
    return tonumber(root["@OutlineSize"])
end

function XmlObjectHelper.GetMaxLengthText(root)
    return tonumber(root["@MaxLengthText"])
end

function XmlObjectHelper.GetShadowEnabled(root)
    if root["@ShadowEnabled"] == "True" then
        XmlObjectHelper.Tip(root, "不支显示密文,在游戏不会显示")
        return true
    end
    return false
end

function XmlObjectHelper.GetPasswordEnable(root)
    if root["@PasswordEnable"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.GetPasswordStyleText(root)
    return root["@PasswordStyleText"] or '*'
end

function XmlObjectHelper.GetIsCustomSize(root)
    if root["@IsCustomSize"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.GetMaxLengthEnable(root)
    if root["@MaxLengthEnable"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.GetVisible(root)
    if root["@VisibleForFrame"] == "False" then
        return false
    end
    return true
end

function XmlObjectHelper.GetClipAble(root)
    if root["@ClipAble"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.GetCheckedState(root)
    if root["@CheckedState"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.CallBackType(root)
    return root["@CallBackType"]
end

function XmlObjectHelper.GetCallBackName(root)
    return root["@CallBackName"]
end

function XmlObjectHelper.GetAlpha(root)
    return tonumber(root["@Alpha"] or 255)
end

function XmlObjectHelper.GetTouchEnable(root)
    if root["@TouchEnable"] == "True" then
        return true
    end
    return false
end

function XmlObjectHelper.GetDisplayState(root)
    if root["@DisplayState"] == "False" then
        return false
    end
    return true
end

function XmlObjectHelper.GetProgressType(root)
    if root["@ProgressType"] == "Right_To_Left" then
        return 1
    end
    return 0
end

function XmlObjectHelper.GetFontSize(root)
    return tonumber(root["@FontSize"])
end

function XmlObjectHelper.GetProgressInfo(root)
    return tonumber(root["@ProgressInfo"] or 80)
end

function XmlObjectHelper.GetShadowOffset(root, scene)
    return { x = tonumber(root["@ShadowOffsetX"]) / SolutionSize.width * 0.8,
        y = tonumber(root["@ShadowOffsetY"]) / SolutionSize.height * 0.6 }
end

function XmlObjectHelper.GetButtonText(root)
    return root["@ButtonText"]
end

function XmlObjectHelper.GetScale9Enable(root, use)
    if root["@Scale9Enable"] == "True" then
        if use == nil then
            XmlObjectHelper.Error(root, "不支九宫格")
        end
        if tonumber(root["@LeftEage"] or 0) > 0 or tonumber(root["@RightEage"] or 0) > 0
            or tonumber(root["@TopEage"] or 0) > 0 or tonumber(root["@BottomEage"] or 0) > 0 then
            XmlObjectHelper.Error(root, "只支持上下左右全为0的拉伸九宫格,请设置不使用或4边为0的拉伸九宫格")
        end
        return true
    end
    return false
end

function XmlObjectHelper.GetScale9Width(root, scene)
    return (tonumber(root["@Scale9Width"] or 0) + 2) / SolutionSize.width * 0.8
end

function XmlObjectHelper.GetScale9Height(root, scene)
    return (tonumber(root["@Scale9Height"] or 0) + 2) / SolutionSize.height * 0.6
end

function XmlObjectHelper.GetSize(root, scene)
    local node = root.Size[1]
    return tonumber(node["@X"] or 0) / SolutionSize.width * 0.8, tonumber(node["@Y"] or 0) / SolutionSize.height * 0.6
end

function XmlObjectHelper.GetScale(root)
    local node = root.Scale[1]
    if node["@ScaleX"] ~= node["@ScaleY"] then
        XmlObjectHelper.Error(root, "缩放X,Y必须保持一致")
    end
    return { scaleX = tonumber(node["@ScaleX"] or 0), scaleY = tonumber(node["@ScaleY"] or 0) }
end

function XmlObjectHelper.GetPosition(root, scene)
    local node = root.Position[1]
    return tonumber(node["@X"] or 0) / SolutionSize.width * 0.8, tonumber(node["@Y"] or 0) / SolutionSize.height * 0.6
end

function XmlObjectHelper.GetAnchorPoint(root)
    local node = root.AnchorPoint[1]
    local x = node["@ScaleX"] or "0.0000"
    local y = node["@ScaleY"] or "0.0000"
    if y == "0.0000" then
        if x == "0.0000" then
            return XmlObjectHelper.AnchorType.LEFT_BOTTOM
        end
        if x == "0.5000" then
            return XmlObjectHelper.AnchorType.BOTTOM
        end
        if x == "1.0000" then
            return XmlObjectHelper.AnchorType.RIGHT_BOTTOM
        end
    end
    if y == "0.5000" then
        if x == "0.0000" then
            return XmlObjectHelper.AnchorType.LEFT
        end
        if x == "0.5000" then
            return XmlObjectHelper.AnchorType.CENTER
        end
        if x == "1.0000" then
            return XmlObjectHelper.AnchorType.RIGHT
        end
    end
    if y == "1.0000" then
        if x == "0.0000" then
            return XmlObjectHelper.AnchorType.LEFT_TOP
        end
        if x == "0.5000" then
            return XmlObjectHelper.AnchorType.TOP
        end
        if x == "1.0000" then
            return XmlObjectHelper.AnchorType.RIGHT_TOP
        end
    end
    XmlObjectHelper.Error(root, "描点不正确,必须是0或者0.5或者1")
end

function XmlObjectHelper.GetAlignmentType(root)
    local h = root["@HorizontalAlignmentType"] or "HT_Left"
    local v = root["@VerticalAlignmentType"] or "VT_Top"
    local k = 0
    if h == "HT_Left" then

    end
    if h == "HT_Center" then
        k = k | XmlObjectHelper.AlignmentType.CENTER
    end
    if h == "HT_Right" then
        k = k | XmlObjectHelper.AlignmentType.RIGHT
    end
    if v == "VT_Top" then

    end
    if v == "VT_Center" then
        k = k | XmlObjectHelper.AlignmentType.VCENTER
    end
    if v == "VT_Bottom" then
        k = k | XmlObjectHelper.AlignmentType.BOTTOM
    end
    return k
end

function XmlObjectHelper.GetColor(root)
    local node = root.CColor[1]
    return { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node["@A"]) }
end

function XmlObjectHelper.GetResource(root, tag)
    local node = root[tag]
    if node == nil then
        return
    end
    node = node[1]
    local plist = node["@Plist"] or ""
    if plist ~= "" then
        XmlObjectHelper.Error(root, "不支持PList文件")
    end
    local file = string.lower(node["@Path"] or "")
    return file
end

function XmlObjectHelper.PngToBlp(png)
    if png == nil then
        return
    end
    png = string.lower(png)
    return string.gsub(png, [[.png]], [[.blp]])
end

function XmlObjectHelper.PngToTga(png)
    if png == nil then
        return ""
    end
    png = string.lower(png)
    return string.gsub(png, [[.png]], [[.tga]])
end

function XmlObjectHelper.CsdToXMUI(png)
    png = string.lower(png)
    return string.gsub(png, [[.csd]], [[.xmui]])
end

function XmlObjectHelper.GetBlendFunc(root)
    local node = root.BlendFunc[1]
    if node["@Src"] ~= "1" then
        XmlObjectHelper.Error(root, "不支BlendFunc模式,请设置为Normal")
    end
    if node["@Dst"] ~= "771" then
        XmlObjectHelper.Error(root, "不支BlendFunc模式,请设置为Normal")
    end
    return { src = node["@Src"], dst = node["@Dst"] }
end

function XmlObjectHelper.GetFlip(root)
    if root["@FlipX"] == "True" then
        XmlObjectHelper.Error(root, "不支翻转X")
    end
    if root["@FlipY"] == "True" then
        XmlObjectHelper.Error(root, "不支翻转Y")
    end
    return { x = root["@FlipX"], y = root["@FlipY"] }
end

function XmlObjectHelper.GetRotationSkew(root)
    if root["@RotationSkewX"] ~= nil then
        XmlObjectHelper.Error(root, "不支倾斜X")
    end
    if root["@RotationSkewY"] ~= nil then
        XmlObjectHelper.Error(root, "不支倾斜Y")
    end
    return { x = root["@RotationSkewX"], y = root["@RotationSkewY"] }
end

function XmlObjectHelper.GetRotationSkew90(root)
    if root["@RotationSkewX"] ~= root["@RotationSkewY"] then
        XmlObjectHelper.Error(root, "倾斜角度x,y必须一样")
    end
    if root["@RotationSkewX"] ~= nil and (root["@RotationSkewX"] ~= "90.0000") then
        XmlObjectHelper.Error(root, "只支持90度倾斜")
    end
    if root["@RotationSkewX"] == "90.0000" then
        return true
    end
    return false
end

function XmlObjectHelper.GetRotationSkewK(root)
    return tostring(math.floor(tonumber(root["@RotationSkewX"]) or 0))
end

function XmlObjectHelper.GetRotationAnchor90(root, anchorType)
    if XmlObjectHelper.GetRotationSkewK(root) == "90" then
        if anchorType == XmlObjectHelper.AnchorType.LEFT_BOTTOM then
            return XmlObjectHelper.AnchorType.LEFT_TOP
        end
        if anchorType == XmlObjectHelper.AnchorType.LEFT_TOP then
            return XmlObjectHelper.AnchorType.RIGHT_TOP
        end
        if anchorType == XmlObjectHelper.AnchorType.RIGHT_TOP then
            return XmlObjectHelper.AnchorType.RIGHT_BOTTOM
        end
        if anchorType == XmlObjectHelper.AnchorType.RIGHT_BOTTOM then
            return XmlObjectHelper.AnchorType.LEFT_BOTTOM
        end
    elseif XmlObjectHelper.GetRotationSkewK(root) == "180" then
        if anchorType == XmlObjectHelper.AnchorType.LEFT_BOTTOM then
            return XmlObjectHelper.AnchorType.RIGHT_TOP
        end
        if anchorType == XmlObjectHelper.AnchorType.LEFT_TOP then
            return XmlObjectHelper.AnchorType.RIGHT_BOTTOM
        end
        if anchorType == XmlObjectHelper.AnchorType.RIGHT_TOP then
            return XmlObjectHelper.AnchorType.LEFT_BOTTOM
        end
        if anchorType == XmlObjectHelper.AnchorType.RIGHT_BOTTOM then
            return XmlObjectHelper.AnchorType.LEFT_TOP
        end
    elseif XmlObjectHelper.GetRotationSkewK(root) == "270" then
        if anchorType == XmlObjectHelper.AnchorType.LEFT_BOTTOM then
            return XmlObjectHelper.AnchorType.RIGHT_BOTTOM
        end
        if anchorType == XmlObjectHelper.AnchorType.LEFT_TOP then
            return XmlObjectHelper.AnchorType.LEFT_BOTTOM
        end
        if anchorType == XmlObjectHelper.AnchorType.RIGHT_TOP then
            return XmlObjectHelper.AnchorType.LEFT_TOP
        end
        if anchorType == XmlObjectHelper.AnchorType.RIGHT_BOTTOM then
            return XmlObjectHelper.AnchorType.RIGHT_TOP
        end
    end
    return anchorType
end

function XmlObjectHelper.AddMapDirectory(filename)
    return [[map\]] .. filename
end

function XmlObjectHelper.CopyRes(root, filename, rot90, flip)
    if filename == nil then
        return
    end
    local c_outpath = fs.canonicalize(OutPath)
    local newFilename = fs.canonicalize(string.lower(filename))
    local p = string.find(newFilename, [[.png]])
    if p ~= nil then
        --png图片
        local convFilename = XmlObjectHelper.PngToTga(newFilename)
        if rot90 then
            convFilename = string.gsub(convFilename, [[.tga]], [[_]] .. rot90 .. [[.tga]])
        end
        local inFilePath = fs.pathAppend(ResPath, newFilename)
        local outFilePath = fs.pathAppend(c_outpath, "resource")
        fs.createDirectory(outFilePath)
        local outFilePath = fs.pathAppend(outFilePath, convFilename)
        if not fs.fileExists(outFilePath) then
            local outPath = fs.removeFileSpec(outFilePath)
            fs.createDirectory(outPath)

            local tool = fs.pathAppend(ToolsPath, 'imageTools.exe') .. ' -i "' .. inFilePath ..
            '" -o "' .. outFilePath .. '"'
            if rot90 then
                tool = tool .. " -r " .. rot90
            end
            if flip then
                tool = tool .. " -f"
            end
            local handle = io.popen(tool, "r")
            if handle == nil then
                error("没有找到工具文件:" .. tool)
            end
            local info = handle:read("*a")
            handle:close()
        end
        --return XmlObjectHelper.AddMapDirectory(convFilename)
        return convFilename
    else
        --其他文件
        local inFilePath = fs.pathAppend(ResPath, newFilename)
        local outFilePath = fs.pathAppend(c_outpath, "map")
        fs.createDirectory(outFilePath)
        local outFilePath = fs.pathAppend(outFilePath, newFilename)
        if not fs.fileExists(outFilePath) then
            local outPath = fs.removeFileSpec(outFilePath)
            fs.createDirectory(outPath)
            fs.copyFile(inFilePath, outFilePath)
        end
    end
    return newFilename
end

function XmlObjectHelper.GetTextColor(root)
    local node = root.TextColor[1]
    return { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node["@A"]) }
end

function XmlObjectHelper.GetShadowColor(root)
    local node = root.ShadowColor[1]
    return { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node["@A"]) }
end

function XmlObjectHelper.GetOutlineColor(root)
    local node = root.OutlineColor[1]
    return { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node["@A"]) }
end

function XmlObjectHelper.GetSingleColor(root)
    local node = root.SingleColor[1]
    local color = { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node
    ["@A"]) }

    return color
end

function XmlObjectHelper.GetFirstColor(root)
    local node = root.FirstColor[1]
    local color = { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node
    ["@A"]) }

    return color
end

function XmlObjectHelper.GetEndColor(root)
    local node = root.EndColor[1]
    local color = { r = tonumber(node["@R"]), g = tonumber(node["@G"]), b = tonumber(node["@B"]), a = tonumber(node
    ["@A"]) }

    return color
end

function XmlObjectHelper.GetColorVector(root)
    local node = root.ColorVector[1]
    local color = { ScaleX = tonumber(node["@ScaleX"]), ScaleY = tonumber(node["@ScaleY"]) }

    return color
end

function XmlObjectHelper.GetInnerNodeSize(root, scene)
    local node = root.InnerNodeSize[1]
    return { width = tonumber(node["@Width"] or 0) / SolutionSize.width * 0.8,
        height = tonumber(node["@Height"] or 0) / SolutionSize.height * 0.6 }
end

function XmlObjectHelper.GetScrollDirectionType(root)
    local tmp = root["@ScrollDirectionType"]
    if tmp == "Vertical" then
        return 0
    end
    if tmp == "Horizontal" then
        return 1
    end
    if tmp == "Vertical_Horizontal" then
        return 2
    end
end

function XmlObjectHelper.FixInnerScrollbar(obj)
    for index, value in ipairs(obj.children) do
        if value.name == "[VerticalScrollbar]" or value.name == "[HorizontalScrollbar]" then
            ---滚动条
            value.y = value.y - (obj.innerNodeSize.height - obj.height)
        end
    end
end

return XmlObjectHelper
