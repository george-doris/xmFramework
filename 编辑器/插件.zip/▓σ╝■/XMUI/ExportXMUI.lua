local XmlObjectHelper = require "XmlObjectHelper"

function ParserChildren(Children,scene)
    local childs = {}
    for index, value in pairs(Children.AbstractNodeData) do
        local ctype = value["@ctype"]
        local parserObject = require(ctype)
        local child = parserObject(value,scene)
        table.insert(childs,child)
    end
    return childs
end

return function (inFile,outFile)
    --#regions 保存源文件
    local f = io.open(inFile,"r")
    local buffer = f:read("a")
    f:close()
    local fs = require "file_system"
    local srcFile = fs.renameExtension(outFile,".src")
    f = io.open(srcFile,"w")
    f:write(buffer)
    f:close()
    --#endregion

    print("************************************************************")
    print('开始解析  '..inFile)
    --#regions 解析文件
    local scene = {}
    local xml = require("xmlSimple").newParser()
    local root = xml:loadFile(inFile)
    root = root.GameFile[1]
    --场景名称
    local child = root.PropertyGroup[1]
    scene.name = child["@Name"]
    print('场景名称:'..scene.name)
    root = root.Content[1].Content[1]
    local ObjectData = root.ObjectData[1]
    scene.className = ObjectData["@CustomClassName"]
    scene.userData = ObjectData["@UserData"]
    child = ObjectData.Size[1]
    scene.width = tonumber(child["@X"])
    scene.height = tonumber(child["@Y"])
    if ObjectData.Children then
        local Children = ObjectData.Children[1]
        scene.children = ParserChildren(Children,scene)
    else
        XmlObjectHelper.Error(scene,"场景内没有任何元素")
    end
    local Serialize = require "Serialize"
    buffer = Serialize.serialize(scene)
    f = io.open(outFile,"w")
    f:write(buffer)
    f:close()
    --#endregion

    print(scene.name..'导出成功\r\n')

    return ""
end